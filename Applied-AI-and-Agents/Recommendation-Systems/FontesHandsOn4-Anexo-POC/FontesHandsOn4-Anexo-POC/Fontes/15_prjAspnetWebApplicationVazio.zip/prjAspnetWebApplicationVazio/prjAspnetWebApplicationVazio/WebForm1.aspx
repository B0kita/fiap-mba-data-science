﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="WebForm1.aspx.cs" Inherits="prjAspnetWebApplicationVazio.WebForm1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
</head>
<body>
    <form id="form1" runat="server">
        <div>Din Din Fintech
            <div></div>
        </div>
        <div>Olá [<asp:DropDownList ID="DropDownList1" runat="server" OnSelectedIndexChanged="DropDownList1_SelectedIndexChanged">
            </asp:DropDownList>
            ]. Ag. 1234 CC. 00012345-6            
            <asp:Button ID="btnAtualizarCliente" runat="server" OnClick="btnAtualizarCliente_Click" Text="Atualizar Cliente" />
&nbsp;<div></div>
        </div>
        <div>Recomendação Open Finance
            <div>
                <asp:GridView ID="GridView1" runat="server">
                </asp:GridView>
            </div>
            <div>-</div>
        </div>
        <div>Recomendação Popularidade
            <div>
                <asp:GridView ID="GridView2" runat="server">
                </asp:GridView>
            </div>
            <div>-</div>
        </div>
        <div>Está curtindo os produtos da Din Din?
            <div>
                <asp:ImageButton ID="ImageButton1" runat="server" ImageUrl="~/likeNao.png" OnClick="ImageButton1_Click" />
                Cartão de Crédito&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:ImageButton ID="ImageButton2" runat="server" ImageUrl="~/likeNao.png" OnClick="ImageButton2_Click" />
                Conta Corrente&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:ImageButton ID="ImageButton3" runat="server" ImageUrl="~/likeNao.png" OnClick="ImageButton3_Click" />
                Crédito Pessoal<br />
                <asp:ImageButton ID="ImageButton4" runat="server" ImageUrl="~/likeNao.png" OnClick="ImageButton4_Click" />
                Poupança&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:ImageButton ID="ImageButton5" runat="server" ImageUrl="~/likeNao.png" OnClick="ImageButton5_Click" />
                Renda Fixa&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <asp:ImageButton ID="ImageButton6" runat="server" ImageUrl="~/likeNao.png" OnClick="ImageButton6_Click" />
                Renda Variável</div>
        </div>
      
        <div>
            <asp:Label ID="lblResultado" runat="server" Text="[Resultado]"></asp:Label>
        </div>
    </form>
</body>
</html>
